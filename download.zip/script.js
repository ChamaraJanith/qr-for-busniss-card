document.getElementById('vcard-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get values
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();
    const company = document.getElementById('company').value.trim();
    const jobTitle = document.getElementById('jobTitle').value.trim();
    const photoUrl = document.getElementById('photoUrl').value.trim();
    
    // IMPORTANT: Replace this URL with your actual public URL after hosting (e.g., Netlify or GitHub Pages)
    // For now, it will work locally if someone is on the same computer, but for others, you MUST host it!
    const baseUrl = window.location.origin + window.location.pathname.replace('index.html', '') + 'download.html';
    const params = new URLSearchParams();
    
    if (firstName) params.append('firstName', firstName);
    if (lastName) params.append('lastName', lastName);
    if (phone) params.append('phone', phone);
    if (email) params.append('email', email);
    if (company) params.append('company', company);
    if (jobTitle) params.append('jobTitle', jobTitle);
    if (photoUrl) params.append('photoUrl', photoUrl);
    
    const qrUrl = `${baseUrl}?${params.toString()}`;
    
    // Clear previous QR code
    const qrDiv = document.getElementById('qrcode');
    qrDiv.innerHTML = '';
    
    // Generate new QR Code (Using the URL instead of raw vCard data)
    new QRCode(qrDiv, {
        text: qrUrl,
        width: 350,
        height: 350,
        colorDark: "#0f172a",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.L
    });
    
    // Show QR container with animation
    const qrContainer = document.getElementById('qr-container');
    qrContainer.classList.remove('hidden');
    
    // Smooth scroll to QR
    setTimeout(() => {
        qrContainer.scrollIntoView({ behavior: 'smooth' });
    }, 100);
});
